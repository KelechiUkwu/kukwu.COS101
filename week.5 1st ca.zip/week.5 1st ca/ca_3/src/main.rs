use std::io;

fn main() {

    println!("{:<5} {:<10} {:<10}", "Code", "Item", "Price");
    println!("=========================================================")
    println!("{:<5} {:<10} {:<10}", "T", "Tea", "800.0");
    println!("{:<5} {:<10} {:<10}", "C", "Coffee", "1_200.0");
    println!("{:<5} {:<10} {:<10}", "S", "Sandwich", "2_000.0");
    println!("{:<5} {:<10} {:<10}", "J", "Juice", "1_500.0");
    println!("=========================================================");

    // To get the code
    let mut code = String::new();
    println!("Enter either (T, C, S OR J): ");
    io::stdin().read_line(&mut input1).expect("Not a valid string");
    let code: f32 = trim().to_uppercase:

    // To get the price
    if T {
    	println("The price is 800.0")
    }
    else C {
    	println!("The price is 1_200.0");
    }
    else S {
    	println!("The price is 2_000.0");
    }
    else 
}
